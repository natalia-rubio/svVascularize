svZeroDSolver is a fast lumped-parameter solver for blood flow and pressure in hemodynamic networks.
